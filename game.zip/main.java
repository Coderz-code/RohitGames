import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;


class Bird {
    private int x;
    private int y;
    static final int height = 57;
    static final int width = 59;
    static final int gravity = 1;
    int hitboxWidth = 29;
    int hitboxHeight = 28;
    int hitboxX;
    int hitboxY;
    int velocity;

    public Bird(int x, int y) {
        this.velocity = -15;
        this.x = x;
        this.y = y;
        this.hitboxX = this.x + 10;
        this.hitboxY = this.y + 18;
    }

    public void drawImage(Graphics2D g2d, JPanel panel) throws IOException {
        this.hitboxX = this.x + 8;
        this.hitboxY = this.y + 6;
        BufferedImage image = ImageIO.read(new File("flappy bird.png"));
        g2d.drawImage(image, this.x, this.y, 59, 57, panel);
    }

    public void jump() {
        if (this.y > 0) {
            this.velocity = -16;
        }

    }

    public void updatePosition() {
        this.y += this.velocity;
        ++this.velocity;
    }

    public boolean checkGameOver() {
        if (this.y >= 455) {
            this.y = 455;
            this.velocity = 0;
            return true;
        } else {
            return false;
        }
    }

    public boolean checkPipeGameOver(Pipes pipes) {
        Rectangle birdBounds = new Rectangle(this.hitboxX, this.hitboxY, this.hitboxWidth, this.hitboxHeight);
        Rectangle pipeBounds = new Rectangle(pipes.x, pipes.y, pipes.width, pipes.height);
        return birdBounds.intersects(pipeBounds);
    }

    public int getY() {
        return this.y;
    }

    public int getX() {
        return this.x;
    }

    public int getWidth() {
        return 59;
    }

    public int getHeight() {
        return 57;
    }

    public void setY(int newY) {
        this.y = newY;
    }
}

class Pipes {
    int x;
    int y;
    int height;
    int width;

    public Pipes(int x, int y, int height, int width) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void drawPipes(Graphics2D g2d) {
        g2d.setColor(new Color(27, 165, 15));
        g2d.fillRect(this.x, this.y, this.width, this.height);
    }
}

class MyPanel extends JPanel implements KeyListener, Runnable {
    Thread myThread;
    int clickCounter = 0;
    Bird bird = new Bird(75, 150);
    int gap = 150;
    Random random = new Random();
    int minY = 50;
    int score = 0;
    int maxY = 250;
    int upHeight;
    int downY;
    Pipes upPipes;
    Pipes downPipes;
    BufferedImage backdrop;

    MyPanel() throws IOException {
        this.upHeight = this.random.nextInt(500 - this.gap - this.minY) + this.minY;
        this.downY = this.upHeight + this.gap;
        this.upPipes = new Pipes(500, 0, this.upHeight, 100);
        this.downPipes = new Pipes(500, this.downY, 500 - this.downY, 100);
        this.backdrop = ImageIO.read(new File("backdrop.jpg"));
        this.setPreferredSize(new Dimension(500, 500));
        this.addKeyListener(this);
        this.setFocusable(true);
        this.myThread = new Thread(this);
        this.myThread.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;

        try {
            g2d.setColor(new Color(181, 101, 29));
            g2d.fillRect(0, 0, 500, 500);
            g2d.drawImage(this.backdrop, (AffineTransform)null, this);
            this.bird.drawImage(g2d, this);
            this.upPipes.drawPipes(g2d);
            this.downPipes.drawPipes(g2d);
            g2d.setColor(Color.black);
            g2d.setFont(new Font("Comic Sans", 1, 15));
            g2d.drawString("Score " + this.score, 400, 40);
        } catch (IOException var4) {
            var4.printStackTrace();
        }

    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == 87 || e.getKeyCode() == 38) {
            this.bird.jump();
        }

    }

    public void keyReleased(KeyEvent e) {
    }

    public void run() {
        this.repaint();

        while(true) {
            this.repaint();
            this.bird.updatePosition();
            this.bird.hitboxX = this.bird.getX() + 10;
            this.bird.hitboxY = this.bird.getY() + 18;
            Pipes var10000 = this.upPipes;
            var10000.x -= 5;
            var10000 = this.downPipes;
            var10000.x -= 5;
            int answer;
            if (this.bird.checkGameOver()) {
                answer = JOptionPane.showConfirmDialog((Component)null, "Game Over! Your score was: " + this.score + "\nWould you like to play again");
                if (answer == 0) {
                    this.bird.velocity = -12;
                    this.bird.setY(150);
                    this.bird.hitboxX = this.bird.getX() + 10;
                    this.bird.hitboxY = this.bird.getY() + 18;
                    this.downPipes.x = 500;
                    this.upPipes.x = 500;
                    this.score = 0;
                    this.upPipes.height = this.random.nextInt(500 - this.gap - this.minY) + this.minY;
                    this.downPipes.y = this.upPipes.height + this.gap;
                    this.downPipes.height = 500 - this.downPipes.y;
                    this.bird.hitboxX = this.bird.getX() + 10;
                    this.bird.hitboxY = this.bird.getY() + 18;
                    this.myThread.interrupt();
                } else {
                    this.myThread.interrupt();
                    System.exit(0);
                }
            }

            if (this.bird.checkPipeGameOver(this.downPipes) || this.bird.checkPipeGameOver(this.upPipes)) {
                answer = JOptionPane.showConfirmDialog((Component)null, "Game Over! Your score was: " + this.score + "\nWould you like to play again");
                if (answer == 0) {
                    this.bird.velocity = -12;
                    this.bird.setY(150);
                    this.bird.hitboxX = this.bird.getX() + 10;
                    this.bird.hitboxY = this.bird.getY() + 18;
                    this.downPipes.x = 500;
                    this.upPipes.x = 500;
                    this.score = 0;
                    this.upPipes.height = this.random.nextInt(500 - this.gap - this.minY) + this.minY;
                    this.downPipes.y = this.upPipes.height + this.gap;
                    this.downPipes.height = 500 - this.downPipes.y;
                    this.bird.hitboxX = this.bird.getX() + 10;
                    this.bird.hitboxY = this.bird.getY() + 18;
                    this.myThread.interrupt();
                } else {
                    this.myThread.interrupt();
                    System.exit(0);
                }
            }

            if (this.bird.hitboxX + this.bird.hitboxWidth > this.downPipes.x + this.downPipes.width && this.bird.hitboxX + this.bird.hitboxWidth > this.upPipes.x + this.upPipes.width) {
                this.upPipes.x = 500;
                this.downPipes.x = 500;
                this.upPipes.height = this.random.nextInt(500 - this.gap - this.minY) + this.minY;
                this.downPipes.y = this.upPipes.height + this.gap;
                this.downPipes.height = 500 - this.downPipes.y;
                ++this.score;
            }

            try {
                Thread.sleep(16L);
            } catch (Exception e) {
            }
        }
    }
}


class MyFrame extends JFrame {
    MyPanel myPanel = new MyPanel();

    MyFrame() throws IOException{
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
        this.setTitle("Flappy Bird");
        this.add(this.myPanel);
        this.setLocation(550, 200);
        this.pack();
        this.setResizable(false);
    }
}




class Main {
    public static void main(String[] args) throws IOException {
        new MyFrame();
    }
}