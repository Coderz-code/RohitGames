import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.Thread;
import java.util.*;

class Main {
    public static void main(String[] args) throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        new MyFrame();
    }
}

class MyPlayer {

    private int x;
    private int y;
    private int width;
    private int height;
    private boolean isJumping;
    private boolean hasLandedOnLedge = false;
    private int gravity;
    private int velocity;
    private boolean isOnLedge;
    private int playerBottom = this.y + this.height;
    Rectangle playerGeometry = new Rectangle(this.x, this.y, this.width, this.height);
    public MyPlayer(int x, int y, int width, int height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.velocity = -20;
        this.gravity = 1;

    }

    public void initPlayerPolygon()
    {
        this.playerGeometry = new Rectangle(this.x, this.y, this.width, this.height);
    }

    public int getPlayerX()
    {
        return this.x;
    }

    public int getPlayerY()
    {
        return this.y;
    }

    public boolean isJumping()
    {
        return this.isJumping;
    }

    public boolean isOnLedge()
    {
        return this.isOnLedge;
    }

    public void setPlayerY(int y)
    {
        this.y = y;
    }

    public void setPlayerX(int x)
    {
        this.x = x;
    }

    public void jump()
    {
        if (!this.isJumping && this.isOnLedge) {
            this.isJumping = true;
            this.isOnLedge = false;
        }
        if(!this.isJumping)
        {
            this.isJumping = true;
        }
    }


    public void doNormalJump()
    {
        if(this.isJumping && !this.isOnLedge)
        {
            this.y += this.velocity;
            this.velocity+=this.gravity;
            if(this.y >= 500 - this.height)
            {
                this.isJumping = false;
                this.velocity = -20;
                this.y = 500 - this.height;
            }
        }
    }

    public void doLedgeJump(Ledge ledge)
    {
        if(this.isOnLedge) {
            if(this.isJumping) {
                this.y += this.velocity;
                this.velocity += this.gravity;
                if (playerBottom >= ledge.getY()) {
                    this.isJumping = false;
                    this.velocity = -20;
                }
            }
        }
    }

    public void CheckSpikeCollision(Spike spike){
        if(spike.spikeShape.intersects(this.playerGeometry)) {
            MyPanel.backgroundMusic.stop();
            JOptionPane.showMessageDialog(null, "Game over");
            System.exit(0);
        }
    }
    public void CheckLedgeCollision(Ledge ledge) {
        if (this.y + this.height >= ledge.getY() && this.x + this.width > ledge.getX() && this.x < ledge.getX() + ledge.getWidth()) {

            if (!this.isJumping) {
                this.y = ledge.getY() - this.height; // Place the player on the ledge
                this.velocity = -20;                // Reset jump velocity
                this.isOnLedge = true;              // Mark the player as on the ledge
            } else {
                if (this.isOnLedge) {
                    this.y = 500 - this.height;
                }
                //System.out.println("falling now!");
                this.isOnLedge = false;
            }

        } else if (this.y + this.height > ledge.getY() && this.x + this.width == ledge.getX()) {
            MyPanel.backgroundMusic.stop();
            JOptionPane.showMessageDialog(null, "Game Over");
            System.exit(0);
        } else if (this.x > ledge.getX() + ledge.getWidth()) {
            if (!this.isJumping) {
                this.y = 500 - this.height;
            }
        }
    }

}

class Spike {
    int[] xPoints;
    int[] yPoints;
    int nPoints;
    Polygon spikeShape;
    public Spike(int[] xPoints, int[] yPoints, int nPoints)
    {
        this.xPoints = xPoints;
        this.yPoints = yPoints;
        this.nPoints = nPoints;
        this.spikeShape = new Polygon(this.xPoints, this.yPoints, this.nPoints);
    }

    public void initSpikeShape()
    {
        this.spikeShape = new Polygon(this.xPoints, this.yPoints, this.nPoints);
    }

    public void setXPoints(int[] xPoints)
    {
        this.xPoints = xPoints;
    }
}

class Ledge {
    int x;
    int y;
    int width;
    int height;
    Rectangle ledgeShape;

    public Ledge(int x, int y, int width, int height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.ledgeShape = new Rectangle(this.x, this.y, this.width, this.height);
    }

    public void setX(int x)
    {
        this.x = x;
    }
    public void setY(int y)
    {
        this.y = y;
    }
    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height)
    {
        this.height = height;
    }

    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getWidth() {
        return this.width;
    }
    public int getHeight() {
        return this.height;
    }

    public void initLedgeShape()
    {
        ledgeShape = new Rectangle(this.x, this.y, this.width, this.height);
    }
}

class MyPanel extends JPanel implements KeyListener, Runnable {

    Scanner diskScanner;
    MyPlayer player;
    File file = new File("obstacles.txt");
    int spikeIndex;
    int ledgeIndex;
    FinishLine finish;

    public static Clip backgroundMusic;

    public MyPanel() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        this.setPreferredSize(new Dimension(500, 500));
        this.setFocusable(true);
        this.addKeyListener(this);
        this.grabFocus();

        diskScanner = new Scanner(file);
        initDiskScanner();
        player = new MyPlayer(50, 465, 35, 35);
        System.out.println("Spikes: " + spikeIndex + "\nLedges: " + ledgeIndex + "Total = " + String.valueOf(spikeIndex + ledgeIndex));
        Thread myThread = new Thread(this);
        myThread.start();

        loadAndPlayMusic("song.wav");
    }

    private void loadAndPlayMusic(String filePath) throws IOException, UnsupportedAudioFileException, LineUnavailableException, LineUnavailableException, UnsupportedAudioFileException, IOException {
        File audioFile = new File(filePath);
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
        backgroundMusic = AudioSystem.getClip();
        backgroundMusic.open(audioStream);
        backgroundMusic.loop(Clip.LOOP_CONTINUOUSLY); // Loop the music indefinitely
        backgroundMusic.start();
    }

    final int MAX_AMOUNT = 2000;
    Spike[] spikes = new Spike[MAX_AMOUNT];
    Ledge[] ledges = new Ledge[MAX_AMOUNT];
    public void initDiskScanner() {
        spikeIndex = 0;
        ledgeIndex = 0;
        while (diskScanner.hasNextLine()) {
            String obstacleType = diskScanner.next();
            int[] xPoints = {0,0,0};
            int[] yPoints = {0,0,0};
            int x;
            int y;
            int width;
            int height;
            int nPoints = 3;
            int finishLineX;
            int finishLineY;
            if(obstacleType.equals("spike"))
            {
                diskScanner.nextLine();
                xPoints[0] = Integer.parseInt(diskScanner.nextLine());
                xPoints[1] = Integer.parseInt(diskScanner.nextLine());
                xPoints[2] = Integer.parseInt(diskScanner.nextLine());
                yPoints[0] = Integer.parseInt(diskScanner.nextLine());
                yPoints[1] = Integer.parseInt(diskScanner.nextLine());
                yPoints[2] = Integer.parseInt(diskScanner.nextLine());
                spikes[spikeIndex] = new Spike(xPoints,yPoints,nPoints);
                spikeIndex++;
                if (spikeIndex >= MAX_AMOUNT) {
                    System.out.println("Maximum number of spikes reached.");
                    break;
                }
            }
            if(obstacleType.equals("ledge"))
            {
                diskScanner.nextLine();
                x = Integer.parseInt(diskScanner.nextLine());
                y = Integer.parseInt(diskScanner.nextLine());
                width = Integer.parseInt(diskScanner.nextLine());
                height = Integer.parseInt(diskScanner.nextLine());
                ledges[ledgeIndex] = new Ledge(x,y,width,height);
                ledgeIndex++;
                if (ledgeIndex >= MAX_AMOUNT) {
                    System.out.println("Maximum number of ledges reached.");
                    break;
                }
            }
            if(obstacleType.equals("finish"))
            {
                diskScanner.nextLine();
                finishLineX = Integer.parseInt(diskScanner.nextLine());
                finish = new FinishLine(finishLineX);
            }

        }
    }




    public void paint(Graphics g)
    {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.fillRect(player.getPlayerX(), player.getPlayerY(), player.playerGeometry.width, player.playerGeometry.height);
        for(int i = 0; i < spikeIndex; i++) {
            g2d.fillPolygon(spikes[i].spikeShape);
        }
        for(int i = 0; i < ledgeIndex; i++)
        {
            g2d.fillRect(ledges[i].getX(),ledges[i].getY(),ledges[i].getWidth(),ledges[i].getWidth());
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_UP)
        {
            player.jump();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    public void run()
    {
        while (true)
        {
            repaint();
            player.doNormalJump();
            player.initPlayerPolygon();
            for(int i = 0; i < spikeIndex; i++) {
                spikes[i].initSpikeShape();
                spikes[i].xPoints[0] -= 5;
                spikes[i].xPoints[1] -= 5;
                spikes[i].xPoints[2] -= 5;
                player.CheckSpikeCollision(spikes[i]);
            }
            for(int i = 0; i < ledgeIndex; i++)
            {
                ledges[i].x-=5;
                player.doLedgeJump(ledges[i]);
                player.CheckLedgeCollision(ledges[i]);
            }

            finish.x-=5;
            if(player.getPlayerX() >= finish.x)
            {
                backgroundMusic.stop();
                JOptionPane.showMessageDialog(null,"You win! 🏆");
                System.exit(0);
            }

            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}


class FinishLine {
    int x;
    public FinishLine(int x)
    {
        this.x = x;
    }
}

class MyFrame extends JFrame {
    MyPanel myPanel = new MyPanel();
    MyFrame() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        this.setVisible(true);
        this.setResizable(true);
        this.setTitle("Rohits's Obstacle Jumper (ROJ)");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.add(myPanel);
        this.pack();
    }
}